package com.voxelbusters.nativeplugins.utilities;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import com.voxelbusters.nativeplugins.features.medialibrary.CameraActivity;

import java.util.List;

/**
 * Created by ayyappa on 13/12/17.
 */

public class IntentUtilities
{

    public static Intent getGalleryIntent(String mimeType)
    {
        Intent requiredIntent = null;

        if (Build.VERSION.SDK_INT < 19) {
            requiredIntent = new Intent(Intent.ACTION_GET_CONTENT, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        }
        else
        {
            requiredIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            requiredIntent.addCategory(Intent.CATEGORY_OPENABLE);
        }

        requiredIntent.setType(mimeType);

        return  requiredIntent;
    }

    public static Intent getCameraIntent(Context context, Uri imageUri )
    {
        Intent requiredIntent = null;
        requiredIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        List<ResolveInfo> resInfoList = context.getPackageManager().queryIntentActivities(requiredIntent, PackageManager.MATCH_ALL);
        for (ResolveInfo resolveInfo : resInfoList) {
            String packageName = resolveInfo.activityInfo.packageName;
            context.grantUriPermission(packageName, imageUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }

        FileUtility.grantPermissions(context, imageUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);

        requiredIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        return  requiredIntent;
    }
}
