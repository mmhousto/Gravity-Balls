package com.voxelbusters.nativeplugins.features.utility;

import com.voxelbusters.nativeplugins.externallibrary.notification.shortcutbadger.ShortcutBadger;
import com.voxelbusters.nativeplugins.NativePluginHelper;

enum eUiType
{
	ALERT_DIALOG, SINGLE_FIELD_PROMPT, LOGIN_PROMPT
}

public class UtilityHandler
{
	// Create singleton instance
	private static UtilityHandler INSTANCE;

	public static UtilityHandler getInstance()
	{
		if (INSTANCE == null)
		{
			INSTANCE = new UtilityHandler();
		}
		return INSTANCE;
	}

	// Make constructor private for making singleton interface
	private UtilityHandler()
	{

	}

	public void setApplicationIconBadgeNumber(int _badgeNumber)
	{
		ShortcutBadger.applyCount(NativePluginHelper.getCurrentContext(), _badgeNumber);
	}
}